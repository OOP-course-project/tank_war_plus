import pygame
import json

# 设置字体和颜色主题
white = (255, 255, 255)  # 文本颜色
black = (0, 0, 0)        # 背景色
grey = (128, 128, 128)    # UI元素颜色
grid_color = (100, 100, 255)  # 网格颜色
selection_color = (0, 128, 0) # 选择区域颜色
text_color = (255, 255, 255)  # 白色

# 设置鼠标悬停的延迟时间
hover_start_time = None
hover_position = None

# 初始化 Pygame 和音效
pygame.init()
pygame.mixer.init()

# 使用统一的字体和颜色渲染文本
def render_text(text):
    return font.render(text, True, text_color)

# 全局变量，用于跟踪当前模式
current_mode = 'grid'  # 默认为网格模式
selection_start = None
selection_end = None
selection_rect = None
is_selecting = False

# 设置帮助信息
show_help = True  # 默认情况下不显示帮助信息
help_text = [
    "H: Hide/Show this help",
    "Click to place or remove an element",
    "U: Undo last action",
    "R: Redo last action",
    "S: Screen shot",
    "Space: Save map"
]

# 设置窗口和颜色
screen_width, screen_height = 800, 600
screen = pygame.display.set_mode((screen_width, screen_height))


# 网格和地图数据设置
grid_size = 24
map_data = {'bricks': [], 'irons': []}

# 加载资源的函数
def load_image(file_path):
    try:
        image = pygame.image.load(file_path)
        return image
    except pygame.error as e:
        print(f"无法加载图片 {file_path}: {e}")
        return None

def draw_selection_area():
    if is_selecting and selection_start:
        current_mouse_pos = pygame.mouse.get_pos()
        rect_params = (min(selection_start[0], current_mouse_pos[0]),
                       min(selection_start[1], current_mouse_pos[1]),
                       abs(current_mouse_pos[0] - selection_start[0]),
                       abs(current_mouse_pos[1] - selection_start[1]))
        pygame.draw.rect(screen, (0, 255, 0), rect_params, 2)


# 显示消息的函数
def show_message(message):
    message_surface = font.render(message, True, white)
    x = (screen_width - message_surface.get_width()) // 2
    y = (screen_height - message_surface.get_height()) // 2
    screen.blit(message_surface, (x, y))
    pygame.display.flip()
    pygame.time.wait(2000)  # 显示消息2秒

# 显示帮助信息的函数
def draw_help():
    # 帮助文本的背景框尺寸
    padding = 10
    text_width = max(font.size(line)[0] for line in help_text) + padding * 2
    text_height = sum(font.size(line)[1] for line in help_text) + padding * (len(help_text) + 1)
    bg_rect = pygame.Rect(screen.get_width() - text_width - 20, 20, text_width, text_height)

    # 绘制半透明背景框
    bg_color = (0, 0, 0, 128)  # 半透明黑色
    s = pygame.Surface((bg_rect.width, bg_rect.height))  # 创建Surface对象
    s.set_alpha(128)  # 设置透明度
    s.fill(bg_color)
    screen.blit(s, (bg_rect.x, bg_rect.y))

    # 绘制帮助文本
    y = bg_rect.y + padding
    for line in help_text:
        text_surface = font.render(line, True, white)
        screen.blit(text_surface, (bg_rect.x + padding, y))
        y += text_surface.get_height() + padding

# 加载音效的函数
def load_sound(file_path):
    try:
        sound = pygame.mixer.Sound(file_path)
        return sound
    except pygame.error as e:
        print(f"无法加载音效 {file_path}: {e}")
        return None

# 加载地图元素图片
brick_image = load_image("brick.png")
iron_image = load_image("iron.png")

#brick_image = load_image(r"../image/brick.png")
#iron_image = load_image(r"../image/iron.png")

# 加载音效
#click_sound = load_sound(r"../music/click.wav")
click_sound = load_sound("click.wav")

# 用户界面设置
font = pygame.font.Font(None, 36)
current_element = 'bricks'
element_images = {'bricks': brick_image, 'irons': iron_image}
ui_area = pygame.Rect(0, 0, 200, screen_height)

# 撤销和重做栈
undo_stack = []
redo_stack = []

# Button 类
class Button:
    def __init__(self, x, y, width, height, text):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.color = grey  # 默认颜色
        self.hover_color = (200, 200, 200)  # 悬停时的颜色
        self.current_color = self.color  # 初始化当前颜色

    def draw(self):
        pygame.draw.rect(screen, self.current_color, self.rect)
        text_render = font.render(self.text, True, white)
        screen.blit(text_render, (self.rect.x + 5, self.rect.y + 5))

    def check_hover(self, mouse_pos):
        if self.rect.collidepoint(mouse_pos):
            self.current_color = self.hover_color
        else:
            self.current_color = self.color
# 创建按钮实例
undo_button = Button(10, 400, 80, 30, 'Undo')
redo_button = Button(100, 400, 80, 30, 'Redo')
save_button = Button(10, 450, 170, 30, 'Save')
screenshot_button = Button(10, 350, 170, 30, 'Screenshot')
mode_button = Button(10, 300, 180, 30, 'Grid Mode')

def draw_ui():
    screen.fill(grey, ui_area)
    y_offset = 10
    for element, image in element_images.items():
        text = font.render(element.capitalize(), True, white)
        screen.blit(text, (10, y_offset))
        y_offset += text.get_height() + 5
        screen.blit(image, (10, y_offset))
        y_offset += image.get_height() + 20

    # 绘制按钮
    undo_button.draw()
    redo_button.draw()
    save_button.draw()
    screenshot_button.draw()
    mode_button.draw()

    # 绘制历史记录的背景框
    history_bg_rect = pygame.Rect(0, 500, 200, 100)  # 将历史记录放在底部
    pygame.draw.rect(screen, (50, 50, 50), history_bg_rect)  # 深灰色背景

    # 绘制历史记录标题
    y_offset = 510  # 从背景框下方开始
    text = font.render("History", True, white)
    screen.blit(text, (10, y_offset))
    y_offset += text.get_height() + 5

    # 绘制历史记录内容
    for action, element, position in reversed(undo_stack[-2:]):  # 显示最近的2个操作
        action_symbol = '+' if action == 'add' else '-'
        element_abbr = element[0]  # 取元素名称的第一个字母作为缩写
        action_text = f"{action_symbol}{element_abbr} @ {position['x']},{position['y']}"
        text = font.render(action_text, True, white)
        screen.blit(text, (10, y_offset))
        y_offset += text.get_height() + 5

def draw_hover_coordinate():
    if hover_position and not ui_area.collidepoint(hover_position):
        current_time = pygame.time.get_ticks()
        if current_time - hover_start_time > 1000:  # 悬停超过1秒
            x, y = hover_position
            grid_x, grid_y = (x - ui_area.width) // grid_size, y // grid_size
            hover_text = f"({grid_x}, {grid_y})"
            text_surface = font.render(hover_text, True, white)
            screen.blit(text_surface, hover_position)  # 在鼠标位置显示坐标



def draw_preview():
    # 创建一个新的Surface用于预览
    preview_surface = pygame.Surface((screen_width - ui_area.width, screen_height))
    preview_surface.fill(black)  # 使用黑色填充背景

    # 遍历地图数据，绘制每个元素
    for element_type, positions in map_data.items():
        for position in positions:
            # 调整位置以适应预览区域
            adjusted_x = position['x'] * grid_size
            adjusted_y = position['y'] * grid_size
            preview_surface.blit(element_images[element_type], (adjusted_x, adjusted_y))

    # 将预览Surface绘制到屏幕上
    screen.blit(preview_surface, (ui_area.width, 0))

def draw_grid():
    number_color = (173, 216, 230)  # 淡蓝色
    # 创建一个专用于行号和列号的小字体对象
    small_font = pygame.font.Font(None, 20)  # 可以调整字号大小

    for x in range(ui_area.width, screen_width, grid_size):
        for y in range(0, screen_height, grid_size):
            pygame.draw.rect(screen, (150, 150, 150), (x, y, grid_size, grid_size), 1)

        # 渲染列号（顶部）
        column_number_text = str(x // grid_size - ui_area.width // grid_size)
        column_number_surface = small_font.render(column_number_text, True, number_color)
        screen.blit(column_number_surface, (x + grid_size / 2 - column_number_surface.get_width() / 2, 0))

    for y in range(0, screen_height, grid_size):
        # 渲染行号（左侧）
        row_number_text = str(y // grid_size)
        row_number_surface = small_font.render(row_number_text, True, number_color)
        screen.blit(row_number_surface, (ui_area.width - row_number_surface.get_width(), y + grid_size / 2 - row_number_surface.get_height() / 2))



def draw_elements():
    for element_type, positions in map_data.items():
        for position in positions:
            screen.blit(element_images[element_type],
                        (position['x'] * grid_size + ui_area.width, position['y'] * grid_size))

def undo():
    if undo_stack:
        action, element, position = undo_stack.pop()
        if action == 'add':
            if position in map_data[element]:
                map_data[element].remove(position)
                redo_stack.append(('remove', element, position))
        elif action == 'remove':
            if position not in map_data[element]:
                map_data[element].append(position)
                redo_stack.append(('add', element, position))

def redo():
    if redo_stack:
        action, element, position = redo_stack.pop()
        if action == 'add':
            if position not in map_data[element]:
                map_data[element].append(position)
                undo_stack.append(('remove', element, position))
        elif action == 'remove':
            if position in map_data[element]:
                map_data[element].remove(position)
                undo_stack.append(('add', element, position))

# 截图
def take_screenshot():
    pygame.image.save(screen, "screenshot.png")
    show_message("Screenshot Taken")

def position_occupied(pos, exclude_element=None):
    """检查给定位置是否已被其他元素占用"""
    for element, positions in map_data.items():
        if element != exclude_element and pos in positions:
            return True
    return False

# 保存地图数据
def save_map():
    with open('map_data.json', 'w') as file:
        json.dump(map_data, file, indent=4)
    show_message("Map Saved Successfully")

# 处理事件
def handle_events():
    global current_element, undo_stack, redo_stack, show_help, \
        current_mode, selection_start, selection_end, selection_rect, \
        is_selecting, hover_start_time, hover_position
    mouse_pos = pygame.mouse.get_pos()

    for event in pygame.event.get():
        if event.type == pygame.MOUSEMOTION:
            hover_position = event.pos
            hover_start_time = pygame.time.get_ticks()  # 更新悬停开始时间
            if is_selecting:
                selection_end = event.pos


        if event.type == pygame.MOUSEBUTTONUP:
            selection_end = event.pos
            is_selecting = False


        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_h:  # 当按下 'H' 键
                show_help = not show_help  # 切换显示状态
            elif event.key == pygame.K_u:
                undo()
            elif event.key == pygame.K_r:
                redo()
            elif event.key == pygame.K_s:
                take_screenshot()
            elif event.key == pygame.K_SPACE:
                save_map()


        if event.type == pygame.QUIT:
            return False

        if event.type == pygame.MOUSEBUTTONDOWN:
            pygame.mixer.Sound.play(click_sound)
            x, y = event.pos
            selection_start = event.pos
            is_selecting = True

            # 撤销、重做和保存按钮的逻辑
            if undo_button.rect.collidepoint(x, y):
                undo()
            elif mode_button.rect.collidepoint(event.pos):
                # 切换模式
                if current_mode == 'grid':
                    current_mode = 'preview'
                    mode_button.text = 'Preview Mode'
                else:
                    current_mode = 'grid'
                    mode_button.text = 'Grid Mode'
            elif redo_button.rect.collidepoint(x, y):
                redo()
            elif screenshot_button.rect.collidepoint(event.pos):
                take_screenshot()
            elif save_button.rect.collidepoint(x, y):
                save_map()
            # UI区域的逻辑
            elif ui_area.collidepoint(x, y):
                y_offset = 10
                for element in element_images:
                    text = font.render(element.capitalize(), True, white)
                    text_height = text.get_height()
                    image = element_images[element]
                    image_rect = image.get_rect(topleft=(10, y_offset + text_height + 5))

                    if image_rect.collidepoint(x, y):
                        current_element = element
                        break

                    y_offset += text_height + image.get_height() + 20


            else:
                # 地图编辑的逻辑
                grid_x, grid_y = (x - ui_area.width) // grid_size, y // grid_size
                element_position = {'x': grid_x, 'y': grid_y}
                if not position_occupied(element_position, current_element):
                    if element_position not in map_data[current_element]:
                        map_data[current_element].append(element_position)
                        undo_stack.append(('add', current_element, element_position))
                        redo_stack.clear()
                    else:
                        map_data[current_element].remove(element_position)
                        undo_stack.append(('remove', current_element, element_position))
                        redo_stack.clear()

    # 更新按钮的悬停状态
    undo_button.check_hover(mouse_pos)
    redo_button.check_hover(mouse_pos)
    save_button.check_hover(mouse_pos)
    screenshot_button.check_hover(mouse_pos)
    mode_button.check_hover(mouse_pos)
    return True


running = True
while running:
    screen.fill(black)

    # 绘制网格模式下的界面
    if current_mode == 'grid':
        draw_ui()
        draw_grid()
        draw_elements()
        draw_hover_coordinate()
    else:
    # 绘制预览模式下的界面
        draw_ui()
        draw_preview()
        draw_hover_coordinate()

    running = handle_events()
    if show_help:
        draw_help()
    pygame.display.flip()

pygame.quit()